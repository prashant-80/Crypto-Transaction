module.exports = {
    TransactionRepository: require('./transaction-repository'),
    EtheriumRepository: require('./etherium-repository'),
    ExpenseRepository: require('./expense-repository')
}
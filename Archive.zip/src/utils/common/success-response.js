const success = {
    success:true,
    message: 'Success',
    data:{},
    error:{}
}

module.exports = {
    success
}
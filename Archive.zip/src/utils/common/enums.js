const SEAT_TYPE = {
    BUSINESS:'bussiness',
    ECONOMY:'economy',
    PREMIUM_ECONOMY:'premium_economy',
    FIRST_CLASS:'first_class'
}

module.exports = {
    SEAT_TYPE
}